-- Loaded after optional legacy addons, before the integrated Ling controller.
ArkInventoryLing = {};
local L=ArkInventoryLing;

function L:Copy(value, seen)
    if type(value)~="table" then return value; end
    seen=seen or {}; if seen[value] then return seen[value]; end
    local result={}; seen[value]=result;
    for key,child in pairs(value) do result[key]=self:Copy(child,seen); end
    return result;
end

L.legacy=PikaBankViewerDB;
-- Stop the old controller before PLAYER_LOGIN. Its data and source files remain intact.
for _,owner in ipairs({PikaBankViewer or {},PikaBankScanner or {}}) do
    if owner.events then
        owner.events:UnregisterAllEvents();
        owner.events:SetScript("OnEvent",nil); owner.events:SetScript("OnUpdate",nil);
    end
    if owner.frame then owner.frame:Hide(); end
end
PikaBankScanner={}; PikaBankViewer=nil;

local ace=LibStub("AceAddon-3.0");
local old=ace:GetAddon("AdiBags",true);
if old then
    old:Disable(); old:SetEnabledState(false);
    old.OnEnable=function(self) self:SetEnabledState(false); end;
end

function L:Import()
    ArkInventoryLingDB=ArkInventoryLingDB or {};
    if ArkInventoryLingDB.legacyImported then return; end
    if type(self.legacy)=="table" then
        for key,value in pairs(self.legacy) do
            if ArkInventoryLingDB[key]==nil then ArkInventoryLingDB[key]=self:Copy(value); end
        end
        ArkInventoryLingDB.legacyImported=true;
    end
end

L.events=CreateFrame("Frame");
L.events:RegisterEvent("PLAYER_LOGIN");
L.events:SetScript("OnEvent",function()
    L:Import(); L.legacy=nil;
    -- Persist the transition only after the new addon and its libraries have loaded.
    for _,name in ipairs({"AdiBags","PikaBankViewer"}) do
        if IsAddOnLoaded and IsAddOnLoaded(name) and DisableAddOn then DisableAddOn(name); end
    end
end);
