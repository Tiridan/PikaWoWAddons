local L=ArkInventoryLing;
local P=PikaBankViewer;

function L:OpenBank()
    ArkInventory.Frame_Main_Show(ArkInventory.Const.Location.Bank);
end

function L:OpenBags()
    ArkInventory.Frame_Main_Show(ArkInventory.Const.Location.Bag);
end

function L:Configure()
    local vault=ArkInventory.Const.Location.Vault;
    ArkInventory.Global.Location[vault].canView=false;
    local data=ArkInventory.db and ArkInventory.db.realm and ArkInventory.db.realm.player;
    -- ArkInventory 3.02.46 stores character data per realm.
    if data and data.data then
        for _,player in pairs(data.data) do
            if player.control then player.control[vault]=false; end
            if player.monitor then player.monitor[vault]=false; end
        end
    end
end

-- Keep the existing Ling window and proven queue; expose it in Ark's location menu.
hooksecurefunc(ArkInventory,"MenuSwitchLocation",function(frame,level,value,offset)
    if level==offset+1 then
        ArkInventory.Lib.DewDrop:AddLine("text","Ling","tooltipTitle","Хранилище Ling",
            "icon","Interface\\AddOns\\ArkInventory\\Ling\\Portrait",
            "iconCoordLeft",0.193359375,"iconCoordRight",0.59765625,"iconCoordTop",0.0390625,"iconCoordBottom",0.443359375,
            "tooltipText","Категории, поиск и получение ресурсов; вдали — сохранённый просмотр.",
            "closeWhenClicked",true,"func",function() P:Open("ling"); end);
    end
end);

hooksecurefunc(P,"CreateUI",function()
    if not P.bankTab or L.uiAttached then return; end
    L.uiAttached=true;
    P.bankTab:Hide();
    P.lingTab:ClearAllPoints(); P.lingTab:SetPoint("TOPLEFT",P.frame,"TOPLEFT",20,-49);
    P.bagsTab=P:Button(P.frame,"Сумки",70,function() L:OpenBags(); end);
    P.bagsTab:SetPoint("LEFT",P.lingTab,"RIGHT",6,0);
end);

-- Keep the compact navigation and give the reclaimed space to search.
hooksecurefunc(P,"Refresh",function()
    if not P.frame or not P.frame:IsShown() or not P.bagsTab then return; end
    P.search:ClearAllPoints();
    P.bankTab:Hide();
    P.search:SetPoint("TOPLEFT",P.frame,"TOPLEFT",204,-50);
    P.search:SetPoint("TOPRIGHT",P.frame,"TOPRIGHT",P.mode=="bank" and -24 or -158,-50);
end);

hooksecurefunc(ArkInventory,"OnEnable",function() L:Configure(); end);
local events=CreateFrame("Frame"); events:RegisterEvent("PLAYER_LOGIN");
events:SetScript("OnEvent",function() L:Configure(); end);

SLASH_ARKLING1="/arkling";
SlashCmdList.ARKLING=function() P:Open("ling"); end;
