---@diagnostic disable: undefined-global
-- Full-text search for the AzerothCore mod-reagent-bank NPC (Ling).
--
-- The server exposes the bank as a gossip tree: a fixed category menu followed
-- by one or more pages of item links.  The scanner deliberately selects only a
-- category, "Next Page", or "Back...".  It never selects an item or the
-- destructive-ish "Deposit All Reagents" action.  Search-result clicks navigate
-- to and highlight the item; withdrawing it remains a deliberate second click.

DialogUI_ReagentSearch = DialogUI_ReagentSearch or {};
local RS = DialogUI_ReagentSearch;

RS.schema = 1;
RS.maxActions = 300;
RS.timeoutSeconds = 120;
RS.actionDelay = 0.12;
RS.resultsPerPage = 9;
RS.lingFrameScaleFactor = 0.78;

local CYRILLIC_LOWER = {
    ["А"]="а", ["Б"]="б", ["В"]="в", ["Г"]="г", ["Д"]="д", ["Е"]="е", ["Ё"]="ё",
    ["Ж"]="ж", ["З"]="з", ["И"]="и", ["Й"]="й", ["К"]="к", ["Л"]="л", ["М"]="м",
    ["Н"]="н", ["О"]="о", ["П"]="п", ["Р"]="р", ["С"]="с", ["Т"]="т", ["У"]="у",
    ["Ф"]="ф", ["Х"]="х", ["Ц"]="ц", ["Ч"]="ч", ["Ш"]="ш", ["Щ"]="щ", ["Ъ"]="ъ",
    ["Ы"]="ы", ["Ь"]="ь", ["Э"]="э", ["Ю"]="ю", ["Я"]="я",
};

local VALID_ANCHOR_POINTS = {
    TOPLEFT = true, TOP = true, TOPRIGHT = true,
    LEFT = true, CENTER = true, RIGHT = true,
    BOTTOMLEFT = true, BOTTOM = true, BOTTOMRIGHT = true,
};

local function Lower(text)
    text = string.lower(tostring(text or ""));
    for upper, lower in pairs(CYRILLIC_LOWER) do
        text = string.gsub(text, upper, lower);
    end
    return text;
end

local function CleanText(text)
    text = tostring(text or "");
    text = string.gsub(text, "|T.-|t", "");
    text = string.gsub(text, "|c%x%x%x%x%x%x%x%x", "");
    text = string.gsub(text, "|r", "");
    text = string.gsub(text, "|H.-|h(.-)|h", "%1");
    text = string.gsub(text, "^%s+", "");
    text = string.gsub(text, "%s+$", "");
    return text;
end

local function OptionKey(text)
    local clean = Lower(CleanText(text));
    clean = string.gsub(clean, "[%s%.]+$", "");
    return clean;
end

local function GetOptions()
    local values = { GetGossipOptions() };
    local options = {};
    for i = 1, #values, 2 do
        local raw = values[i] or "";
        table.insert(options, {
            raw = raw,
            text = CleanText(raw),
            key = OptionKey(raw),
            iconType = values[i + 1],
            originalIndex = ((i + 1) / 2),
            itemID = tonumber(string.match(raw, "|Hitem:(%d+)")),
            texture = RS:IconFromOption(raw),
        });
    end
    return options;
end

local function FindOption(options, key)
    key = Lower(key or "");
    for _, option in ipairs(options) do
        if (option.key == key) then
            return option;
        end
    end
    return nil;
end

local function IsRootMenu(options)
    return FindOption(options, "deposit all reagents") ~= nil;
end

local function IsBack(option)
    return option and (option.key == "back" or option.key == "назад");
end

local function IsNext(option)
    return option and (option.key == "next page" or option.key == "следующая страница");
end

local function IsPrevious(option)
    return option and (option.key == "previous page" or option.key == "предыдущая страница");
end

local function ParseNPCEntry(guid)
    if (not guid) then return nil; end
    local hex = guid;
    if (string.sub(hex, 1, 2) == "0x" or string.sub(hex, 1, 2) == "0X") then
        hex = string.sub(hex, 3);
    end
    while (string.len(hex) < 16) do hex = "0" .. hex; end
    if (string.upper(string.sub(hex, 1, 1)) ~= "F") then return nil; end
    return tonumber(string.sub(hex, 7, 10), 16);
end

local function CurrentCacheKey()
    local realm = (GetRealmName and GetRealmName()) or "realm";
    local player = UnitName("player") or "player";
    local entry = ParseNPCEntry(UnitGUID("npc"));
    return realm .. ":" .. player .. ":" .. tostring(entry or Lower(UnitName("npc") or "ling"));
end

local function EnsureSettings()
    if (not DialogUISettings) then DialogUISettings = {}; end
    if (not DialogUISettings.reagentSearchBanks) then
        DialogUISettings.reagentSearchBanks = {};
    end
    return DialogUISettings.reagentSearchBanks;
end

function RS:IsBusy()
    return self.scan ~= nil or self.navigation ~= nil;
end

function RS:IsLing(options)
    if (Lower(UnitName("npc") or "") == "ling") then return true; end
    if (options and IsRootMenu(options)) then return true; end
    return self:IsBusy();
end

function RS:GetIndex()
    if (not self.cacheKey) then return nil; end
    local banks = DialogUISettings and DialogUISettings.reagentSearchBanks;
    local index = banks and banks[self.cacheKey];
    if (index and index.schema == self.schema and index.complete and index.items) then
        return index;
    end
    return nil;
end

function RS:SetStatus(text, r, g, b)
    if (not self.statusText) then return; end
    self.statusText:SetText(text or "");
    self.statusText:SetTextColor(r or 0.85, g or 0.78, b or 0.60);
end

function RS:SuspendAutoSelect()
    if (self.savedAutoSelect == nil) then
        self.savedAutoSelect = DialogUISettings and DialogUISettings.autoSelect and true or false;
    end
    if (DialogUISettings) then DialogUISettings.autoSelect = false; end
end

function RS:RestoreAutoSelect()
    if (self.savedAutoSelect ~= nil and DialogUISettings) then
        DialogUISettings.autoSelect = self.savedAutoSelect;
    end
    self.savedAutoSelect = nil;
end

function RS:CancelPending()
    self.pending = nil;
end

function RS:QueueSelect(option, transitionText)
    if (not option or self.pending) then return false; end
    local busy = self.scan or self.navigation;
    if (not busy) then return false; end
    if (busy.actions >= self.maxActions) then
        self:Abort("Превышен безопасный лимит переходов.");
        return false;
    end
    self.pending = {
        due = GetTime() + self.actionDelay,
        optionIndex = option.originalIndex,
        transitionText = transitionText,
    };
    return true;
end

function RS:Abort(reason)
    self:TraceWrite("SCANNER_ABORT", { reason = reason });
    local hadScan = self.scan ~= nil;
    self.scan = nil;
    self.navigation = nil;
    self:CancelPending();
    self:RestoreAutoSelect();
    if (self.scanButton) then self.scanButton:Enable(); end
    if (hadScan and reason) then
        self:SetStatus(reason .. " Старый индекс сохранён.", 1.0, 0.45, 0.35);
    elseif (reason) then
        self:SetStatus(reason, 1.0, 0.45, 0.35);
    end
    self:RefreshScanButton();
end

function RS:BuildCategories(options)
    local categories = {};
    for _, option in ipairs(options) do
        if (not option.itemID and option.key ~= "deposit all reagents" and not IsBack(option)
                and not IsNext(option) and not IsPrevious(option)) then
            table.insert(categories, {
                text = option.text,
                key = option.key,
            });
        end
    end
    return categories;
end

function RS:FindCategoryOption(options, category)
    for _, option in ipairs(options) do
        if (option.key == category.key) then return option; end
    end
    return nil;
end

function RS:StorePageItems(options)
    local scan = self.scan;
    local category = scan.categories[scan.categoryIndex];
    for _, option in ipairs(options) do
        if (option.itemID) then
            local name = string.match(option.raw, "|h%[([^%]]+)%]|h");
            name = name or option.text;
            name = string.gsub(name, "^%[", "");
            name = string.gsub(name, "%]%s*%(%d+%)%s*$", "");
            local amount = tonumber(string.match(option.text, "%((%d+)%)%s*$")) or 0;
            local seenKey = tostring(option.itemID);
            local existing = scan.seen[seenKey];
            local item = {
                id = option.itemID,
                texture = option.texture,
                name = name,
                amount = amount,
                category = category.text,
                categoryKey = category.key,
                page = scan.page,
            };
            if (existing) then
                scan.items[existing] = item;
            else
                table.insert(scan.items, item);
                scan.seen[seenKey] = #scan.items;
            end
        end
    end
end

function RS:CompleteScan()
    local scan = self.scan;
    table.sort(scan.items, function(a, b)
        return Lower(a.name) < Lower(b.name);
    end);
    local banks = EnsureSettings();
    banks[self.cacheKey] = {
        schema = self.schema,
        complete = true,
        scannedAt = time(),
        npc = UnitName("npc") or "Ling",
        categories = scan.categories,
        items = scan.items,
    };
    local count = #scan.items;
    self:TraceWrite("SCAN_COMPLETE", { count = count, actions = scan.actions });
    self.scan = nil;
    self:CancelPending();
    self:RestoreAutoSelect();
    self:SetStatus("Индекс готов: " .. count .. " реагентов. Введите название.", 0.45, 1.0, 0.55);
    self:RefreshScanButton();
    self:RefreshResults();
end

function RS:ProcessScan(options)
    local scan = self.scan;
    if (not scan) then return; end
    if (GetTime() > scan.deadline) then
        self:Abort("Сервер не успел ответить за " .. self.timeoutSeconds .. " сек.");
        return;
    end

    if (scan.phase == "toRoot") then
        if (IsRootMenu(options)) then
            scan.categories = self:BuildCategories(options);
            if (#scan.categories == 0) then
                self:Abort("Не удалось распознать категории Ling.");
                return;
            end
            scan.phase = "categories";
            scan.categoryIndex = 1;
            scan.page = 0;
        else
            local back;
            for _, option in ipairs(options) do
                if (IsBack(option)) then
                    back = option;
                    break
                end
            end
            if (back) then
                self:SetStatus("Возвращаюсь к списку категорий...");
                self:QueueSelect(back, "root");
            else
                self:Abort("Это меню не похоже на банк реагентов Ling.");
            end
            return;
        end
    end

    if (IsRootMenu(options)) then
        if (scan.categoryIndex > #scan.categories) then
            self:CompleteScan();
            return;
        end
        local category = scan.categories[scan.categoryIndex];
        local option = self:FindCategoryOption(options, category);
        if (not option) then
            self:Abort("Категория «" .. category.text .. "» исчезла с сервера.");
            return;
        end
        scan.page = 0;
        self:SetStatus("Сканирование " .. scan.categoryIndex .. "/" .. #scan.categories .. ": " .. category.text);
        self:QueueSelect(option, "category");
        return;
    end

    local back;
    local nextPage;
    for _, option in ipairs(options) do
        if (IsBack(option)) then back = option;
        elseif (IsNext(option)) then nextPage = option;
        end
    end
    if (not back) then
        self:Abort("Получена неизвестная страница; сканирование остановлено безопасно.");
        return;
    end

    self:StorePageItems(options);
    if (nextPage) then
        scan.page = scan.page + 1;
        self:QueueSelect(nextPage, "next");
    else
        scan.categoryIndex = scan.categoryIndex + 1;
        scan.page = 0;
        self:QueueSelect(back, "root");
    end
end

function RS:StartScan()
    if (self.scan) then
        self:Abort("Сканирование остановлено.");
        return;
    end
    if (self.navigation) then
        self:Abort("Переход отменён.");
    end
    if ((InCombatLockdown and InCombatLockdown()) or UnitAffectingCombat("player")) then
        self:SetStatus("Сканирование недоступно в бою.", 1.0, 0.45, 0.35);
        return;
    end
    local options = GetOptions();
    if (not self:IsLing(options)) then
        self:SetStatus("Сначала откройте диалог с Ling.", 1.0, 0.45, 0.35);
        return;
    end
    self.cacheKey = CurrentCacheKey();
    self:SuspendAutoSelect();
    self.scan = {
        phase = "toRoot",
        categories = nil,
        categoryIndex = 0,
        page = 0,
        items = {},
        seen = {},
        actions = 0,
        deadline = GetTime() + self.timeoutSeconds,
    };
    self:SetStatus("Начинаю безопасное сканирование...");
    self:TraceWrite("SCAN_START", { cacheKey = self.cacheKey });
    self:RefreshScanButton();
    self:ProcessScan(options);
end

function RS:HighlightItem(item)
    local wanted = Lower(item.name);
    local found = false;
    for i = 1, NUMGOSSIPBUTTONS or 32 do
        local button = getglobal("DGossipTitleButton" .. i);
        if (button) then
            button:UnlockHighlight();
            if (button:IsVisible() and string.find(Lower(CleanText(button:GetText() or "")), wanted, 1, true)) then
                button:LockHighlight();
                found = true;
            end
        end
    end
    self.highlightUntil = GetTime() + 5;
    if (found) then
        self:SetStatus("Открыто и подсвечено: " .. item.name .. ". Получение — отдельным кликом.", 0.45, 1.0, 0.55);
    else
        self:SetStatus("Страница открыта, но предмет изменился. Обновите индекс.", 1.0, 0.65, 0.25);
    end
end

function RS:ProcessNavigation(options)
    local nav = self.navigation;
    if (not nav) then return; end
    if (GetTime() > nav.deadline) then
        self:Abort("Переход к реагенту занял слишком много времени.");
        return;
    end

    if (IsRootMenu(options)) then
        local category = { key = nav.item.categoryKey, text = nav.item.category };
        local option = self:FindCategoryOption(options, category);
        if (not option) then
            self:Abort("Категория «" .. nav.item.category .. "» больше не найдена.");
            return;
        end
        nav.stage = "pages";
        nav.page = 0;
        self:SetStatus("Открываю: " .. nav.item.category .. " - стр. " .. (nav.item.page + 1));
        self:QueueSelect(option, "category");
        return;
    end

    if (nav.stage == "toRoot") then
        local back;
        for _, option in ipairs(options) do
            if (IsBack(option)) then
                back = option;
                break
            end
        end
        if (back) then
            self:QueueSelect(back, "root");
        else
            self:Abort("Не удалось вернуться к категориям Ling.");
        end
        return;
    end

    if (nav.page < nav.item.page) then
        local nextPage;
        for _, option in ipairs(options) do
            if (IsNext(option)) then
                nextPage = option;
                break
            end
        end
        if (not nextPage) then
            self:Abort("Сохранённая страница больше не существует. Обновите индекс.");
            return;
        end
        nav.page = nav.page + 1;
        self:QueueSelect(nextPage, "next");
        return;
    end

    self.navigation = nil;
    self:CancelPending();
    self:RestoreAutoSelect();
    self:HighlightItem(nav.item);
    self:RefreshScanButton();
end

function RS:NavigateTo(item)
    if ((InCombatLockdown and InCombatLockdown()) or UnitAffectingCombat("player")) then
        self:SetStatus("Переход недоступен в бою.", 1.0, 0.45, 0.35);
        return;
    end
    if (self.scan) then
        self:SetStatus("Сначала завершите или остановите сканирование.", 1.0, 0.65, 0.25);
        return;
    end
    self:Abort();
    self:SuspendAutoSelect();
    self.navigation = {
        item = item,
        stage = "toRoot",
        page = 0,
        actions = 0,
        deadline = GetTime() + 30,
    };
    self:TraceWrite("NAVIGATION_START", { id = item.id, category = item.category, page = item.page });
    self:RefreshScanButton();
    self:ProcessNavigation(GetOptions());
end

function RS:Matches(item, query)
    if (query == "") then return true; end
    local haystack = Lower(item.name .. " " .. item.category);
    for token in string.gmatch(Lower(query), "%S+") do
        if (not string.find(haystack, token, 1, true)) then return false; end
    end
    return true;
end

function RS:RefreshResults()
    if (not self.resultButtons) then return; end
    local index = self:GetIndex();
    local query = self.searchBox and self.searchBox:GetText() or "";
    self.filtered = {};
    if (index) then
        for _, item in ipairs(index.items) do
            if (self:Matches(item, query)) then table.insert(self.filtered, item); end
        end
    end
    local count = #self.filtered;
    for i, button in ipairs(self.resultButtons) do
        local item = self.filtered[i];
        if (item) then
            button.item = item;
            button.nameText:SetText(item.name .. (item.amount > 0 and ("  x" .. item.amount) or ""));
            button.pathText:SetText(item.category .. "  -  стр. " .. (item.page + 1));
            button:Show();
        else
            button.item = nil;
            button:Hide();
        end
    end
    if (not self.scan and not self.navigation) then
        if (not index) then
            self:SetStatus("Индекс ещё не создан — нажмите «Сканировать».");
        elseif (query == "") then
            self:SetStatus("В индексе " .. #index.items .. " реагентов. Введите название.");
        elseif (count == 0) then
            self:SetStatus("Совпадений нет. Возможно, индекс нужно обновить.", 1.0, 0.65, 0.25);
        elseif (count > self.resultsPerPage) then
            self:SetStatus("Найдено " .. count .. ". Показаны первые " .. self.resultsPerPage .. " — уточните запрос.");
        else
            self:SetStatus("Найдено: " .. count .. ". Клик откроет путь, но не заберёт предмет.");
        end
    end
end

function RS:RefreshScanButton()
    if (not self.scanButton) then return; end
    if (self.scan) then
        self.scanButton:SetText("Стоп");
    elseif (self.navigation) then
        self.scanButton:SetText("Переход...");
        self.scanButton:Disable();
        return;
    elseif (self:GetIndex()) then
        self.scanButton:SetText("Обновить");
    else
        self.scanButton:SetText("Сканировать");
    end
    self.scanButton:Enable();
end

function RS:UpdatePanelSide()
    if (not self.panel) then return; end
    local scale = DialogUI_Config and DialogUI_Config.Get and DialogUI_Config:Get("frameScale") or 1.0;
    self.panel:SetScale(scale);
    self.panel:ClearAllPoints();
    local position = DialogUISettings and DialogUISettings.reagentSearchPosition;
    if (position and VALID_ANCHOR_POINTS[position.point]
            and VALID_ANCHOR_POINTS[position.relativePoint]
            and type(position.x) == "number" and type(position.y) == "number") then
        self.panel:SetPoint(position.point, UIParent, position.relativePoint, position.x, position.y);
        return;
    end
    local side = DialogUI_Config and DialogUI_Config.Get and DialogUI_Config:Get("frameSide") or "LEFT";
    if (side == "RIGHT") then
        self.panel:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -430, -104);
    else
        self.panel:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 430, -104);
    end
end

function RS:SavePanelPosition()
    if (not self.panel) then return; end
    local point, _, relativePoint, x, y = self.panel:GetPoint(1);
    if (not VALID_ANCHOR_POINTS[point] or not VALID_ANCHOR_POINTS[relativePoint]) then return; end
    EnsureSettings();
    DialogUISettings.reagentSearchPosition = {
        point = point,
        relativePoint = relativePoint,
        x = x or 0,
        y = y or 0,
    };
end

function RS:ResetPanelPosition()
    EnsureSettings();
    DialogUISettings.reagentSearchPosition = nil;
    self:UpdatePanelSide();
    self:SetStatus("Положение окна поиска сброшено.", 0.45, 1.0, 0.55);
end

function RS:RestoreStandardRows()
    for i = 1, NUMGOSSIPBUTTONS or 32 do
        local button = getglobal("DGossipTitleButton" .. i);
        if (button) then
            button:ClearAllPoints();
            if (i == 1) then
                button:SetPoint("TOPLEFT", DGossipGreetingText, "BOTTOMLEFT", -10, -20);
            else
                button:SetPoint("TOPLEFT", getglobal("DGossipTitleButton" .. (i - 1)), "BOTTOMLEFT", 0, -10);
            end
            local fontString = button:GetFontString();
            if (fontString) then
                fontString:ClearAllPoints();
                fontString:SetPoint("LEFT", button, "LEFT", 30, 0);
                fontString:SetWidth(275);
                fontString:SetJustifyH("LEFT");
            end
        end
    end
end

function RS:ApplyCompactLingRows()
    for i = 1, NUMGOSSIPBUTTONS or 32 do
        local button = getglobal("DGossipTitleButton" .. i);
        if (button) then
            button:ClearAllPoints();
            if (i == 1) then
                button:SetPoint("TOPLEFT", DGossipGreetingText, "BOTTOMLEFT", -10, -9);
            else
                button:SetPoint("TOPLEFT", getglobal("DGossipTitleButton" .. (i - 1)), "BOTTOMLEFT", 0, -1);
            end
            local fontString = button:GetFontString();
            if (fontString) then
                fontString:ClearAllPoints();
                fontString:SetPoint("LEFT", button, "LEFT", 5, 0);
                fontString:SetWidth(370);
                fontString:SetJustifyH("LEFT");
            end
            local gossipIcon = getglobal(button:GetName() .. "GossipIcon");
            if (gossipIcon) then gossipIcon:Hide(); end
            if (button:IsVisible()) then
                button:SetHeight(math.max(24, button:GetTextHeight() + 3));
            else
                button:SetHeight(24);
            end
        end
    end
end

function RS:ApplyGossipLayout()
    local options = GetOptions();
    local isLing = self:IsLing(options);
    local scale = DialogUI_Config and DialogUI_Config.Get and DialogUI_Config:Get("frameScale") or 1.0;
    if (isLing) then
        DGossipFrame:SetScale(scale * self.lingFrameScaleFactor);
        self:ApplyCompactLingRows();
        self.lingLayoutActive = true;
    elseif (self.lingLayoutActive) then
        DGossipFrame:SetScale(scale);
        self:RestoreStandardRows();
        self.lingLayoutActive = nil;
    end
    self:UpdatePanelSide();
    if (DGossipGreetingScrollFrame) then
        DGossipGreetingScrollFrame:UpdateScrollChildRect();
    end
end

function RS:RestoreGossipLayout()
    if (not self.lingLayoutActive) then return; end
    local scale = DialogUI_Config and DialogUI_Config.Get and DialogUI_Config:Get("frameScale") or 1.0;
    DGossipFrame:SetScale(scale);
    self:RestoreStandardRows();
    self.lingLayoutActive = nil;
end

function RS:ShowForCurrentNPC(options)
    if (not self.panel) then return; end
    if (PikaBankViewer and PikaBankViewer:IsLing()) then self.panel:Hide(); return; end
    if (self:IsLing(options)) then
        self.cacheKey = CurrentCacheKey();
        self:UpdatePanelSide();
        self.panel:Show();
        self:RefreshScanButton();
        self:RefreshResults();
    else
        self.panel:Hide();
    end
end

function RS:CreateUI()
    if (self.panel or not DGossipFrame) then return; end
    local panel = CreateFrame("Frame", "DialogUIReagentSearchPanel", UIParent);
    panel:SetWidth(370);
    panel:SetHeight(455);
    panel:SetFrameStrata("DIALOG");
    panel:SetFrameLevel(50);
    panel:SetMovable(true);
    panel:EnableMouse(true);
    if (panel.SetClampedToScreen) then panel:SetClampedToScreen(true); end
    panel:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 24,
        insets = { left = 6, right = 6, top = 6, bottom = 6 },
    });
    panel:SetBackdropColor(0.07, 0.055, 0.035, 0.97);
    panel:Hide();
    self.panel = panel;

    local dragBar = CreateFrame("Button", "DialogUIReagentSearchDragBar", panel);
    dragBar:SetPoint("TOPLEFT", panel, "TOPLEFT", 12, -9);
    dragBar:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -12, -9);
    dragBar:SetHeight(28);
    dragBar:RegisterForDrag("LeftButton");
    dragBar:RegisterForClicks("RightButtonUp");
    dragBar:SetScript("OnDragStart", function()
        panel:StartMoving();
    end);
    dragBar:SetScript("OnDragStop", function()
        panel:StopMovingOrSizing();
        RS:SavePanelPosition();
    end);
    dragBar:SetScript("OnClick", function(_, mouseButton)
        if (mouseButton == "RightButton") then RS:ResetPanelPosition(); end
    end);
    dragBar:SetScript("OnEnter", function(dragHandle)
        GameTooltip:SetOwner(dragHandle, "ANCHOR_TOP");
        GameTooltip:SetText("Окно поиска реагентов", 1, 0.85, 0.35);
        GameTooltip:AddLine("Левая кнопка: перетащить", 0.8, 0.8, 0.8);
        GameTooltip:AddLine("Правая кнопка: сбросить положение", 0.8, 0.8, 0.8);
        GameTooltip:Show();
    end);
    dragBar:SetScript("OnLeave", function() GameTooltip:Hide(); end);

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge");
    title:SetPoint("TOPLEFT", panel, "TOPLEFT", 18, -16);
    title:SetText("Поиск в банке реагентов");
    title:SetTextColor(1.0, 0.82, 0.35);

    local dragHint = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall");
    dragHint:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -18, -18);
    dragHint:SetText("перетащить");
    dragHint:SetTextColor(0.55, 0.55, 0.55);

    local search = CreateFrame("EditBox", "DialogUIReagentSearchBox", panel, "InputBoxTemplate");
    search:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -13);
    search:SetWidth(220);
    search:SetHeight(26);
    search:SetAutoFocus(false);
    search:SetMaxLetters(80);
    search:SetTextInsets(8, 8, 0, 0);
    search:SetScript("OnTextChanged", function() RS:RefreshResults(); end);
    search:SetScript("OnEscapePressed", function(editBox) editBox:ClearFocus(); end);
    search:SetScript("OnEnterPressed", function(editBox)
        editBox:ClearFocus();
        if (RS.filtered and RS.filtered[1]) then RS:NavigateTo(RS.filtered[1]); end
    end);
    self.searchBox = search;

    local scan = CreateFrame("Button", "DialogUIReagentScanButton", panel, "UIPanelButtonTemplate");
    scan:SetPoint("LEFT", search, "RIGHT", 10, 0);
    scan:SetWidth(105);
    scan:SetHeight(25);
    scan:SetText("Сканировать");
    scan:SetScript("OnClick", function() RS:StartScan(); end);
    self.scanButton = scan;

    local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall");
    hint:SetPoint("TOPLEFT", search, "BOTTOMLEFT", 2, -7);
    hint:SetPoint("RIGHT", panel, "RIGHT", -18, 0);
    hint:SetJustifyH("LEFT");
    hint:SetText("Введите часть названия. Enter открывает первый результат.");
    hint:SetTextColor(0.65, 0.65, 0.65);

    local status = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall");
    status:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 18, 15);
    status:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -18, 15);
    status:SetHeight(34);
    status:SetJustifyH("LEFT");
    status:SetJustifyV("BOTTOM");
    self.statusText = status;

    self.resultButtons = {};
    local previous;
    for i = 1, self.resultsPerPage do
        local button = CreateFrame("Button", "DialogUIReagentResult" .. i, panel);
        button:SetWidth(332);
        button:SetHeight(30);
        if (previous) then
            button:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -2);
        else
            button:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, -11);
        end
        local highlight = button:CreateTexture(nil, "HIGHLIGHT");
        highlight:SetAllPoints(button);
        highlight:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight");
        highlight:SetBlendMode("ADD");
        button:SetHighlightTexture(highlight);
        local nameText = button:CreateFontString(nil, "OVERLAY", "GameFontNormal");
        nameText:SetPoint("TOPLEFT", button, "TOPLEFT", 5, -2);
        nameText:SetPoint("TOPRIGHT", button, "TOPRIGHT", -5, -2);
        nameText:SetJustifyH("LEFT");
        nameText:SetTextColor(1.0, 0.88, 0.52);
        button.nameText = nameText;
        local pathText = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall");
        pathText:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 5, 1);
        pathText:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -5, 1);
        pathText:SetJustifyH("LEFT");
        pathText:SetTextColor(0.62, 0.62, 0.62);
        button.pathText = pathText;
        button:SetScript("OnClick", function(resultButton)
            if (resultButton.item) then RS:NavigateTo(resultButton.item); end
        end);
        button:SetScript("OnEnter", function(resultButton)
            if (not resultButton.item) then return; end
            GameTooltip:SetOwner(resultButton, "ANCHOR_RIGHT");
            GameTooltip:SetText(resultButton.item.name, 1, 0.85, 0.35);
            GameTooltip:AddLine(resultButton.item.category .. " - страница " .. (resultButton.item.page + 1), 0.8, 0.8, 0.8);
            GameTooltip:AddLine("Открыть и подсветить; предмет не забирается.", 0.45, 1.0, 0.55);
            GameTooltip:Show();
        end);
        button:SetScript("OnLeave", function() GameTooltip:Hide(); end);
        table.insert(self.resultButtons, button);
        previous = button;
    end
    self:UpdatePanelSide();
end

-- Opt-in Ling diagnostics. Records client-visible API/events, not network packets.
-- Kept in this already-loaded file so an in-game /reload also loads the tracer.
RS.traceMaxEvents = 1000;
RS.traceDuration = 600;

function RS:TracePrint(text)
    DEFAULT_CHAT_FRAME:AddMessage("|cff80dfff[Ling debug]|r " .. text);
end

function RS:TraceText(value)
    local text = tostring(value or "");
    if (#text > 2048) then return string.sub(text, 1, 2048) .. " <truncated>"; end
    return text;
end

function RS:TraceWrite(kind, data)
    if (not self.traceActive) then return; end
    local db = DialogUISettings.reagentTrace;
    if (#db.events >= self.traceMaxEvents) then
        self:TraceStop("event_limit");
        return;
    end
    data = data or {};
    data.event = kind;
    data.at = time();
    data.elapsed = math.floor((GetTime() - self.traceStarted) * 1000 + 0.5) / 1000;
    data.session = db.session;
    data.menu = self.traceMenuSerial;
    data.mode = self.scan and "scan" or (self.navigation and "navigation" or "idle");
    db.events[#db.events + 1] = data;
end

function RS:TraceInventory(reason, baseline)
    if (not self.traceActive) then return; end
    local counts, links = {}, {};
    for bag = 0, 4 do
        for slot = 1, GetContainerNumSlots(bag) do
            local link = GetContainerItemLink(bag, slot);
            local id = link and tonumber(string.match(link, "item:(%d+)"));
            if (id) then
                local _, count = GetContainerItemInfo(bag, slot);
                counts[id] = (counts[id] or 0) + (count or 0);
                links[id] = link;
            end
        end
    end
    local previous = self.traceBags or {};
    self.traceBags = counts;
    if (baseline) then
        self:TraceWrite("BAGS_BASELINE", { reason = reason, counts = counts });
        return;
    end
    local changes = {};
    for id, count in pairs(counts) do
        if (count ~= (previous[id] or 0)) then
            changes[#changes + 1] = { id = id, before = previous[id] or 0,
                after = count, delta = count - (previous[id] or 0), link = links[id] };
        end
    end
    for id, count in pairs(previous) do
        if (not counts[id]) then
            changes[#changes + 1] = { id = id, before = count, after = 0, delta = -count };
        end
    end
    if (#changes > 0) then
        table.sort(changes, function(a, b) return a.id < b.id; end);
        self:TraceWrite("BAGS_DELTA", { reason = reason, changes = changes });
    end
end

function RS:TraceGossip(options)
    if (not self.traceActive) then return; end
    -- Do not use IsLing's "scanner busy" fallback to identify a new NPC.
    if (Lower(UnitName("npc") or "") ~= "ling" and not IsRootMenu(options)) then
        if (self.traceOpen or self.traceUntil) then
            self:TraceWrite("OTHER_NPC_OPENED");
        end
        self.traceOpen, self.traceUntil, self.traceSampleAt = nil, nil, nil;
        self.traceMenu = nil;
        return;
    end
    if (not self.traceOpen and not self.traceUntil) then
        self:TraceInventory("Ling opened", true);
    else
        self:TraceInventory("GOSSIP_SHOW");
    end
    self.traceOpen, self.traceUntil = true, nil;
    self.traceMenuSerial = (self.traceMenuSerial or 0) + 1;
    local menu = {};
    for i = 1, math.min(#options, 64) do
        local option = options[i];
        menu[i] = { index = option.originalIndex, raw = self:TraceText(option.raw),
            itemID = option.itemID, iconType = option.iconType,
            amount = tonumber(string.match(option.text, "%((%d+)%)%s*$")) };
    end
    self.traceMenu = menu;
    self:TraceWrite("GOSSIP_SHOW", { npc = UnitName("npc"), guid = UnitGUID("npc"),
        cacheKey = CurrentCacheKey(), greeting = self:TraceText(GetGossipText()),
        options = menu, optionCount = #options, truncated = #options > 64 });
end

function RS:TraceSelected(index, code)
    if (not self.traceActive or not self.traceMenu) then return; end
    if (not self.traceOpen and (not self.traceClosedAt or GetTime() - self.traceClosedAt > 0.2)) then return; end
    -- Secure post-hook: use the last received menu, never call SelectGossipOption here.
    local option = self.traceMenu[tonumber(index) or 0];
    self:TraceWrite("SELECT_GOSSIP_OPTION", { index = index, option = option,
        code = code ~= nil and self:TraceText(code) or nil,
        source = self.scan and "scanner" or (self.navigation and "search_navigation" or "outside_scanner") });
    self.traceSampleAt = GetTime() + 0.25;
end

function RS:TraceClosed()
    if (not self.traceActive or not self.traceOpen) then return; end
    self:TraceWrite("GOSSIP_CLOSED");
    self:TraceInventory("GOSSIP_CLOSED");
    self.traceOpen = nil;
    self.traceClosedAt = GetTime();
    self.traceUntil = GetTime() + 15;
    self.traceSampleAt = GetTime() + 0.25;
end

function RS:TraceStop(reason)
    if (not self.traceActive) then return; end
    -- Metadata also records the stop when the event array is full.
    local db = DialogUISettings.reagentTrace;
    db.stoppedAt, db.stopReason = time(), reason or "manual";
    db.stopElapsed = GetTime() - self.traceStarted;
    if (#db.events < self.traceMaxEvents) then
        self:TraceWrite("TRACE_STOP", { reason = db.stopReason });
    end
    self.traceActive, self.traceOpen, self.traceUntil = nil, nil, nil;
    self.traceSampleAt, self.traceMenu, self.traceBags = nil, nil, nil;
    self:TracePrint("Запись остановлена (" .. db.stopReason .. "), событий: " .. #db.events .. ". Для сохранения на диск: /reload.");
end

function RS:TraceStart()
    if (self.traceActive) then self:TracePrint("Запись уже включена."); return; end
    EnsureSettings();
    local db = DialogUISettings.reagentTrace;
    if (not db) then
        db = { schema = 1, events = {}, session = 0 };
        DialogUISettings.reagentTrace = db;
    end
    if (db.schema ~= 1 or type(db.events) ~= "table") then
        self:TracePrint("Неизвестная схема журнала; сохранённые данные оставлены без изменений."); return;
    end
    if (#db.events >= self.traceMaxEvents - 1) then
        self:TracePrint("Журнал заполнен. Сохраните /reload и передайте запись для разбора."); return;
    end
    db.session = (tonumber(db.session) or 0) + 1;
    self.traceActive, self.traceStarted = true, GetTime();
    self.traceMenuSerial, self.traceClosedAt = 0, nil;
    self:TraceWrite("TRACE_START", { realm = GetRealmName(), player = UnitName("player"),
        version = GetAddOnMetadata("DialogUI", "Version") or "1.0.8", duration = self.traceDuration, limit = self.traceMaxEvents });
    self:TracePrint("Запись включена на 10 минут. Откройте Ling; остановка: /lingtrace off.");
    if (UnitName("npc") and ((DGossipFrame and DGossipFrame:IsShown())
            or (GossipFrame and GossipFrame:IsShown())
            or (PikaBankViewer and PikaBankViewer.online))) then
        self:TraceGossip(GetOptions());
    end
end

function RS:TraceUpdate()
    if (not self.traceActive) then return; end
    local now = GetTime();
    if (now - self.traceStarted >= self.traceDuration) then self:TraceStop("timeout"); return; end
    if (self.traceSampleAt and now >= self.traceSampleAt) then
        self.traceSampleAt = nil;
        self:TraceInventory("settled");
    end
    if (self.traceUntil and now > self.traceUntil) then
        self:TraceInventory("post-close window ended");
        self.traceUntil, self.traceMenu, self.traceBags = nil, nil, nil;
    end
end

function RS:TraceEvent(event, ...)
    if (not self.traceActive) then return; end
    if (event == "PLAYER_LOGOUT") then
        if (self.traceBags) then self:TraceInventory("PLAYER_LOGOUT"); end
        self:TraceStop("logout_or_reload"); return;
    end
    if (not self.traceOpen and not (self.traceUntil and GetTime() <= self.traceUntil)) then return; end
    if (event == "BAG_UPDATE") then
        self:TraceWrite(event, { bag = (...) });
        self:TraceInventory(event);
        self.traceSampleAt = GetTime() + 0.25;
    else
        local args = {};
        for i = 1, math.min(select("#", ...), 12) do
            local value = select(i, ...);
            if (type(value) == "string") then args[i] = self:TraceText(value);
            elseif (type(value) == "number" or type(value) == "boolean") then args[i] = value; end
        end
        self:TraceWrite(event, { args = args });
    end
end

SLASH_DIALOGUILINGTRACE1 = "/lingtrace";
SlashCmdList["DIALOGUILINGTRACE"] = function(message)
    local command = Lower(CleanText(message));
    if (command == "on") then RS:TraceStart();
    elseif (command == "off") then
        if (RS.traceActive) then
            if (RS.traceBags) then RS:TraceInventory("manual stop"); end
            RS:TraceStop("manual");
        else RS:TracePrint("Запись уже выключена."); end
    else
        local db = DialogUISettings and DialogUISettings.reagentTrace;
        RS:TracePrint((RS.traceActive and "Запись включена" or "Запись выключена")
            .. "; событий: " .. tostring(db and db.events and #db.events or 0)
            .. ". /lingtrace on - начать, /lingtrace off - остановить, /lingtrace status - состояние.");
    end
end;
hooksecurefunc("SelectGossipOption", function(index, code) RS:TraceSelected(index, code); end);

function RS:OnGossipShow()
    local options = GetOptions();
    self:TraceGossip(options);
    if (PikaBankViewer) then PikaBankViewer:OnGossip(options); end
    self:ShowForCurrentNPC(options);
    if (not self:IsBusy()) then return; end
    self:CancelPending();
    self.pending = { due = GetTime() + self.actionDelay, process = true };
end

function RS:OnGossipClosed()
    self:TraceClosed();
    if (PikaBankViewer) then PikaBankViewer:OnClosed(); end
    if (self:IsBusy()) then self:Abort("Диалог с Ling закрыт."); end
    if (self.panel) then self.panel:Hide(); end
    self:RestoreGossipLayout();
end

function RS:OnUpdate()
    self:TraceUpdate();
    local now = GetTime();
    local busy = self.scan or self.navigation;
    if (busy and now > busy.deadline) then
        self:Abort("Истёк таймаут операции.");
        return;
    end
    if (self.pending and now >= self.pending.due) then
        local pending = self.pending;
        self.pending = nil;
        if (pending.process) then
            local options = GetOptions();
            if (self.scan) then self:ProcessScan(options);
            elseif (self.navigation) then self:ProcessNavigation(options);
            end
        elseif (pending.optionIndex) then
            local active = self.scan or self.navigation;
            if (active) then
                active.actions = active.actions + 1;
                SelectGossipOption(pending.optionIndex);
            end
        end
    end
    if (self.highlightUntil and now >= self.highlightUntil) then
        self.highlightUntil = nil;
        for i = 1, NUMGOSSIPBUTTONS or 32 do
            local button = getglobal("DGossipTitleButton" .. i);
            if (button) then button:UnlockHighlight(); end
        end
    end
end

local eventFrame = CreateFrame("Frame", "DialogUIReagentSearchEventFrame");
eventFrame:RegisterEvent("VARIABLES_LOADED");
eventFrame:RegisterEvent("GOSSIP_SHOW");
eventFrame:RegisterEvent("GOSSIP_CLOSED");
eventFrame:RegisterEvent("PLAYER_REGEN_DISABLED");
eventFrame:RegisterEvent("PLAYER_LOGOUT");
eventFrame:RegisterEvent("BAG_UPDATE");
eventFrame:RegisterEvent("CHAT_MSG_SYSTEM");
eventFrame:RegisterEvent("CHAT_MSG_LOOT");
eventFrame:RegisterEvent("CHAT_MSG_MONSTER_SAY");
eventFrame:RegisterEvent("CHAT_MSG_MONSTER_WHISPER");
eventFrame:RegisterEvent("CHAT_MSG_ADDON");
eventFrame:RegisterEvent("UI_ERROR_MESSAGE");
eventFrame:RegisterEvent("UI_INFO_MESSAGE");
eventFrame:SetScript("OnEvent", function(_, eventName, ...)
    if (eventName == "VARIABLES_LOADED") then
        EnsureSettings();
        RS:CreateUI();
    elseif (eventName == "GOSSIP_SHOW") then
        RS:OnGossipShow();
    elseif (eventName == "GOSSIP_CLOSED") then
        RS:OnGossipClosed();
    elseif (eventName == "PLAYER_REGEN_DISABLED" and RS:IsBusy()) then
        RS:Abort("Операция остановлена при входе в бой.");
    else
        RS:TraceEvent(eventName, ...);
    end
end);
eventFrame:SetScript("OnUpdate", function() RS:OnUpdate(); end);

-- Shared adapter: one scanner and one canonical index for search and bank view.
function RS:GetOptions() return GetOptions(); end
function RS:GetContextKey() return CurrentCacheKey(); end
function RS:IconFromOption(raw)
    local path = string.match(raw or "", "|T([^:|]+)");
    if path and string.find(string.lower(path), "^interface[/\\]")
            and not string.find(string.lower(path), "questionmark", 1, true)
            and not string.find(string.lower(path), "wowunknownitem", 1, true) then
        return (string.gsub(path, "/", "\\"));
    end
end
