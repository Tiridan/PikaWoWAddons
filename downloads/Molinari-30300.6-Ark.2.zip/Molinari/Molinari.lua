﻿local addon = ...
local button = CreateFrame('Button', addon, UIParent, 'SecureActionButtonTemplate, AutoCastShineTemplate, SecureHandlerStateTemplate')
-- SecureHandlerStateTemplate's OnLoad replaces the shine template's OnLoad.
-- Initialize the inherited 16 textures explicitly when that handler was skipped.
if type(button.sparkles) ~= 'table' then AutoCastShine_OnLoad(button) end
local spells = {}
local WEAPON, ARMOR

local function ScanTooltip()
	for index = 1, GameTooltip:NumLines() do
		local text = _G['GameTooltipTextLeft'..index]:GetText()
		local info = spells[text]
		if info then
			return unpack(info)
		end
	end
end

local function IsDisenchantable(itemLink)
	if not spells.disenchant then return end
	local _, _, quality, _, _, iType = GetItemInfo(itemLink)
	if not quality or not iType then return end
	-- Uncommon (2) – Rare (3). Epic (4) можно добавить, если нужно
	if (iType == ARMOR or iType == WEAPON) and quality >= 2 and quality <= 4 then
		return unpack(spells.disenchant)
	end
end

local function Clickable()
	return not InCombatLockdown() and IsAltKeyDown()
end

-- ArkInventory uses its own bag indices. Never fall back to frame IDs for
-- an Ark frame: an offline/bank view may have the same IDs as a live bag.
local function ResolveSlot(frame)
	if not frame then return end
	local data = frame.ARK_Data
	local bag, slot
	if data then
		local ark = ArkInventory
		if not ark or not ark.Const or not ark.Global or not ark.BagID_Blizzard then return end
		local location = ark.Global.Location[data.loc_id]
		if data.loc_id ~= ark.Const.Location.Bag or not location or location.isOffline
			or ark.Global.Mode.Edit or not data.bag_id or not data.slot_id then return end
		bag, slot = ark.BagID_Blizzard(data.loc_id, data.bag_id), data.slot_id
	else
		local parent = frame:GetParent()
		if not parent or not parent.GetID or not frame.GetID then return end
		bag, slot = parent:GetID(), frame:GetID()
	end
	if type(bag) ~= 'number' or type(slot) ~= 'number' or bag < 0 or bag > 4
		or slot < 1 or slot > GetContainerNumSlots(bag) then return end
	return bag, slot
end

local function ClearAction()
	button:SetAttribute('*type*', nil)
	button:SetAttribute('spell', nil)
	button:SetAttribute('target-bag', nil)
	button:SetAttribute('target-slot', nil)
end

local function Disperse(self)
	if InCombatLockdown() then
		self:RegisterEvent('PLAYER_REGEN_ENABLED')
	else
		ClearAction()
		self.source = nil
		self:Hide()
		self:ClearAllPoints()
		AutoCastShine_AutoCastStop(self)
	end
end

function button:MODIFIER_STATE_CHANGED(event, key)
	if self:IsShown() and (key == 'LALT' or key == 'RALT') then
		Disperse(self)
	end
end

function button:PLAYER_REGEN_ENABLED(event)
	self:UnregisterEvent(event)
	Disperse(self)
end

GameTooltip:HookScript('OnTooltipSetItem', function(self)
	local _, itemLink = self:GetItem()
	if not itemLink or not Clickable() then return end

	-- сначала пробуем mill / prospect по тексту тултипа
	local spell, r, g, b = ScanTooltip()

	-- если не нашли — проверяем, можно ли распылить
	if not spell then
		spell, r, g, b = IsDisenchantable(itemLink)
	end

	if spell then
		local focus = GetMouseFocus()
		if not focus then return end
		if focus == button then focus = button.source and button.source.frame end
		local bag, slot = ResolveSlot(focus)
		if not bag or GetContainerItemLink(bag, slot) ~= itemLink then return end
		button.source = {frame=focus, bag=bag, slot=slot, link=itemLink, spell=spell}
		button:ClearAllPoints()
		button:SetAllPoints(focus)
		button:Show()
		AutoCastShine_AutoCastStart(button, r, g, b)
	end
end)

-- Configure the protected action only for this hardware click, after checking
-- the live slot again. A failed cast must not equip/use the item via /use.
button:SetScript('PreClick', function(self)
	if InCombatLockdown() then return end
	ClearAction()
	local source = self.source
	if not Clickable() or not source or not source.frame:IsVisible() or GetCursorInfo()
		or SpellIsTargeting() or UnitCastingInfo('player') or UnitChannelInfo('player') then return end
	local bag, slot = ResolveSlot(source.frame)
	if bag ~= source.bag or slot ~= source.slot or GetContainerItemLink(bag, slot) ~= source.link then
		Disperse(self)
		return
	end
	local _, count, locked = GetContainerItemInfo(bag, slot)
	if locked or not count or ((source.spell == GetSpellInfo(31252) or source.spell == GetSpellInfo(51005)) and count < 5) then return end
	self:SetAttribute('*type*', 'spell')
	self:SetAttribute('spell', source.spell)
	self:SetAttribute('target-bag', bag)
	self:SetAttribute('target-slot', slot)
end)
button:SetScript('PostClick', function()
	if not InCombatLockdown() then ClearAction() end
end)

function button:PLAYER_LOGIN()
	WEAPON, ARMOR = GetAuctionItemClasses()

	if IsSpellKnown(51005) then -- Milling
		spells[ITEM_MILLABLE] = {GetSpellInfo(51005), 0.5, 1, 0.5}
	end
	if IsSpellKnown(31252) then -- Prospecting
		spells[ITEM_PROSPECTABLE] = {GetSpellInfo(31252), 1, 0.5, 0.5}
	end
	if IsSpellKnown(13262) then -- Disenchant
		-- цвет синий
		spells.disenchant = {GetSpellInfo(13262), 0.5, 0.5, 1}
	end
end

do
	button:SetScript('OnLeave', Disperse)
	button:SetScript('OnEvent', function(self, event, ...) self[event](self, event, ...) end)
	button:SetFrameStrata('DIALOG')
	button:RegisterEvent('MODIFIER_STATE_CHANGED')
	button:RegisterEvent('PLAYER_LOGIN')
	button:RegisterForClicks('LeftButtonUp')
	button:SetAttribute('_onstate-combat', [[if newstate == 'combat' then self:Hide() end]])
	RegisterStateDriver(button, 'combat', '[combat] combat; peace')
	button:Hide()
	for _, sparks in pairs(button.sparkles) do
		sparks:SetHeight(sparks:GetHeight() * 3)
		sparks:SetWidth(sparks:GetWidth() * 3)
	end
end
