local LIB_NAME, LIB_VERSION = "LibAbacus-3.0", 1
local lib = LibStub:NewLibrary(LIB_NAME, LIB_VERSION)
if not lib then return end

local function FormatMoney(value)
    value = tonumber(value) or 0
    local gold = math.floor(value / 10000)
    local silver = math.floor((value % 10000) / 100)
    local copper = value % 100
    local text = ""
    if gold > 0 then text = gold .. "|cffffd700g|r " end
    if silver > 0 or gold > 0 then text = text .. silver .. "|cffc7c7cfs|r " end
    return text .. copper .. "|cffeda55fc|r"
end

function lib:FormatMoneyCondensed(value)
    return FormatMoney(value)
end

function lib:FormatMoneyShort(value)
    return FormatMoney(value)
end

function lib:FormatMoneyFull(value)
    return FormatMoney(value)
end

function lib:FormatMoneyExtended(value)
    return FormatMoney(value)
end
